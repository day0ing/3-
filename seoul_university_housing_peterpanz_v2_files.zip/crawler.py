import asyncio, json, re
from pathlib import Path
from datetime import datetime, timezone
from statistics import mean
from urllib.parse import urljoin
from bs4 import BeautifulSoup
from playwright.async_api import async_playwright

ROOT=Path(__file__).parent
CFG=json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
OUT=ROOT/"data/data.json"

def clean(s): return re.sub(r"\s+"," ",s or "").strip()

def won10k(s):
    if not s: return None
    s=clean(s).replace(",","")
    m=re.search(r"(\d+(?:\.\d+)?)\s*억",s)
    e=float(m.group(1))*10000 if m else 0
    m2=re.search(r"(\d+(?:\.\d+)?)\s*만",s)
    if m2: return e+float(m2.group(1))
    if m: return e
    m=re.search(r"(\d+(?:\.\d+)?)",s)
    return float(m.group(1)) if m else None

def extract(text,label):
    m=re.search(re.escape(label)+r"\s*[:：]?\s*([^\n]{1,80})",text)
    return clean(m.group(1)) if m else None

def parse(url,html):
    soup=BeautifulSoup(html,"html.parser")
    text=clean(soup.get_text(" ",strip=True))
    title=clean(soup.title.get_text(" ",strip=True)) if soup.title else ""
    addr=None
    m=re.search(r"(서울특별시\s+[가-힣]+구\s+[가-힣0-9]+동(?:\s+\S+)?)",text)
    if m: addr=m.group(1)
    deal=extract(text,"거래방식")
    deposit=None; rent=None
    if deal:
        if "월세" in deal:
            mm=re.search(r"(\d[\d,]*)\s*만원?\s*/\s*(\d[\d,]*)",deal)
            if mm: deposit=float(mm.group(1).replace(",","")); rent=float(mm.group(2).replace(",",""))
        elif "전세" in deal or "매매" in deal:
            mm=re.search(r"(\d[\d,]*)\s*만원?",deal)
            if mm: deposit=float(mm.group(1).replace(",",""))
    fee=extract(text,"관리비")
    if fee and "없음" not in fee: fee=won10k(fee)
    area=extract(text,"전용/공급면적")
    am=re.search(r"([\d.]+)\s*m",area or "")
    area=float(am.group(1)) if am else None
    room=extract(text,"방/욕실개수")
    rm=re.search(r"(\d+)\s*개",room or "")
    return {
      "house_id": (re.search(r"/house/(\d+)",url) or [None,None])[1],
      "title":title,"address":addr,"deal_type":deal,
      "deposit_10k_krw":deposit,"monthly_rent_10k_krw":rent,
      "management_fee_10k_krw":fee,"area_m2":area,
      "rooms":int(rm.group(1)) if rm else None,"source_url":url,
      "crawled_at":datetime.now(timezone.utc).isoformat()
    }

async def main():
    async with async_playwright() as p:
        browser=await p.chromium.launch(headless=True)
        page=await browser.new_page(viewport={"width":1440,"height":1000},
          user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/155 Safari/537.36")
        await page.goto(CFG["source"],wait_until="domcontentloaded",timeout=60000)
        await page.wait_for_timeout(2500)

        links=set()
        for _ in range(CFG["max_scrolls"]):
            for href in await page.locator("a[href]").evaluate_all("(els)=>els.map(e=>e.href)"):
                if "/house/" in href: links.add(urljoin(CFG["source"],href))
            await page.evaluate("window.scrollTo(0,document.body.scrollHeight)")
            await page.wait_for_timeout(CFG["scroll_wait_ms"])
        links=list(links)[:CFG["max_detail_pages"]]
        print("FOUND",len(links),"detail links")

        listings=[]
        for i,url in enumerate(links,1):
            try:
                await page.goto(url,wait_until="domcontentloaded",timeout=60000)
                await page.wait_for_timeout(350)
                item=parse(url,await page.content())
                if item["address"] and item["address"].startswith("서울특별시"):
                    listings.append(item)
                print(i,"/",len(links),item["address"],item["deal_type"])
            except Exception as e:
                print("SKIP",url,str(e)[:160])
            await page.wait_for_timeout(CFG["detail_delay_ms"])
        await browser.close()

    results=[]
    for u in CFG["universities"]:
        matched=[x for x in listings if u["district"] in (x["address"] or "") and u["dong"] in (x["address"] or "")]
        def avg(k):
            v=[x[k] for x in matched if isinstance(x.get(k),(int,float))]
            return round(mean(v),1) if v else None
        results.append({**u,"listing_count":len(matched),
          "avg_deposit_10k_krw":avg("deposit_10k_krw"),
          "avg_monthly_rent_10k_krw":avg("monthly_rent_10k_krw"),
          "avg_management_fee_10k_krw":avg("management_fee_10k_krw"),
          "listings":matched})
    OUT.write_text(json.dumps({"source":CFG["source"],
      "generated_at":datetime.now(timezone.utc).isoformat(),
      "universities":results},ensure_ascii=False,indent=2),encoding="utf-8")
    print("WROTE",OUT)

if __name__=="__main__": asyncio.run(main())
